// Función para cerrar sesión
function logout() {
    // Muestra un mensaje de confirmación al cerrar sesión
    alert('Has cerrado sesión.');
    // Redirige a la página de inicio de sesión o de inicio
    window.location.href = 'inicio.html'; // Ajusta la ruta a la página que desees redirigir.
}

// Obtiene el botón de cierre de sesión por su id
const logoutButton = document.getElementById('logoutButton');

// Agrega un evento de clic al botón para cerrar sesión
logoutButton.addEventListener('click', logout);
