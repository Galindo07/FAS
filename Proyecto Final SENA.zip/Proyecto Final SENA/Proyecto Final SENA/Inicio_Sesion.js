// Credenciales de ejemplo
const correctUsername = 'usuario';
const correctPassword = 'contraseña';

// Obtener el formulario y el elemento para el mensaje
const form = document.getElementById('loginForm');
const message = document.getElementById('message');

// Añadir un controlador de eventos al formulario para manejar el envío
form.addEventListener('submit', function (event) {
    // Prevenir el comportamiento predeterminado de enviar el formulario
    event.preventDefault();

    // Obtener los valores ingresados por el usuario
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validar las credenciales
    if (username === correctUsername && password === correctPassword) {
        // Si las credenciales son correctas
        message.textContent = 'Inicio de sesión exitoso.';
    } else {
        // Si las credenciales son incorrectas
        message.textContent = 'Nombre de usuario o contraseña incorrectos. Inténtalo de nuevo.';
    }
});