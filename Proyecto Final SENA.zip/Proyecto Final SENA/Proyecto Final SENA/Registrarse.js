// Función para manejar el registro
function register(event) {
    // Prevenir el comportamiento predeterminado de enviar el formulario
    event.preventDefault();

    // Obtener los valores ingresados por el usuario
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Aquí podrías agregar lógica adicional, como verificar si el nombre de usuario ya existe
    // o enviar los datos a un servidor para crear la cuenta.

    // Por ahora, simplemente muestra un mensaje de confirmación
    const message = document.getElementById('message');
    message.textContent = `Registro exitoso para el usuario ${username}.`;
}

// Obtiene el formulario de registro por su id
const registerForm = document.getElementById('registerForm');

// Agrega un evento de envío al formulario
registerForm.addEventListener('submit', register);
